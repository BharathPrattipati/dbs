package com.arrays.practice;

import java.util.Arrays;
import java.util.stream.IntStream;

public class ArrayFill {

	public static void main(String[] args) {
		int[] in = new int[10];
		Arrays.fill(in, 2, 8, 10);;
		System.out.println(IntStream.of(in).sum());

	}

}

package com.arrays.practice;

public class ArrayRotation {
	public static void main(String[] args){
		int[] arr = {1,2,3,4,5,6,7,8,9};
		int n = 2;
		int[] res = rotateArray(arr,n);
		for(int i=0; i<res.length;i++)
		{
			System.out.print(res[i]+" ");
		}
	}
	
		
		public static int[] rotateArray(int[] a, int n)
		{
			int off = n%a.length;
			int temp = 0;
			for(int i=0; i<n; i++)
			{
				for(int j=a.length-1;j>a.length-n-1;j--)
				{
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
			return a;
		}
}

	
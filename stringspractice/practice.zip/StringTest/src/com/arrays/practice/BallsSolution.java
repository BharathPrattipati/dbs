package com.arrays.practice;
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

	public class BallsSolution {

	    static BigInteger substrings(String balls) {
	    	
	        BigInteger bg = new BigInteger("0");
	        for(int i=0; i< balls.length(); i++)
	        {
	            for(int j=i+1; j<= balls.length();j++)
	            {
	                String s = balls.substring(i,j);
	                System.out.println(s);
	                BigInteger b = new BigInteger(s);
	                bg = bg.add(b);
	            }
	        }
	        return bg;
	    }

	    public static void main(String[] args) {
	        Scanner in = new Scanner(System.in);
	        String balls = in.next();
	        BigInteger result = substrings(balls);
	        System.out.println(result);
	        in.close();
	    }
	}


package com.arrays.practice;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class FibanocciSolution {

    static BigInteger fibonacciModified(BigInteger t1, BigInteger t2, int n) {
        //BigInteger bg = new BigInteger("0");
    	BigInteger t = new BigInteger("0");
        if( n == 1 )
        {
            t = t1;
        }
        else if( n ==2 )
        {
            t = t2;
        }
        else
        {
            t = fibonacciModified(t1,t2,n-2).add( 
                (fibonacciModified(t1, t2, n-1).multiply(fibonacciModified(t1, t2, n-1))));
        }
        
        return t;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String t1 = in.next();
        String t2 = in.next();
        BigInteger bg1 = new BigInteger(t1);
        BigInteger bg2 = new BigInteger(t2);
        int n = in.nextInt();
        BigInteger result = fibonacciModified(bg1, bg2, n);
        System.out.println(result);
        in.close();
    }
}

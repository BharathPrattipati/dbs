package com.arrays.practice;

import java.util.Random;
import java.util.stream.IntStream;

public class ForEach {

	public static void main(String[] args) {
		Random random = new Random();
		random.ints().limit(10).forEach(System.out::println);
		int[] in = {1,2,3,4,5,1,2,3,4,5,6,7,8,9};
		IntStream is =  IntStream.of(in).distinct();
		is.forEach(System.out::println);
		

	}

}

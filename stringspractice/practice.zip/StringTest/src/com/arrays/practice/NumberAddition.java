package com.arrays.practice;

public class NumberAddition {

	public static void main(String[] args) {
		int num = 12345;
		long result = 0;
		String s = String.valueOf(num);
		for(int i=1; i <= s.length(); i++)
		{
			
		}

	}

}

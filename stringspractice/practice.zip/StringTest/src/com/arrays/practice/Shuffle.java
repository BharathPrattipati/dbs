package com.arrays.practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Shuffle {

	public static void main(String[] args) {
		int[] in = {1,2,3,4,5,6,7,8,9,10};
		List l1 = Arrays.asList(in);
		System.out.println(l1);
		List l = new ArrayList<Integer>();
		l.add(1);
		l.add(2);
		l.add(3);
		Collections.shuffle(l);
		Collections.shuffle(l1);
		System.out.println(l);

	}

}

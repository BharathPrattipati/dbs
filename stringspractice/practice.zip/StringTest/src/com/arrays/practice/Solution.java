package com.arrays.practice;

import java.util.Scanner;

public class Solution {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
        StringBuffer sb = new StringBuffer("");
        int test = scan.nextInt();
        String[] s = new String[test];
        int count = 0;
        for(int i=0; i< test; i++){
            int option = scan.nextInt();
            switch(option)
            {
                case 1 : String s1 = scan.next();
                         s[count] = sb.toString();
                         sb.append(s1);
                         count++;
                         break;
                case 2 : int k = scan.nextInt();
                         int l = sb.length();
                         s[count] = sb.toString();
                         sb.delete(l-k,l);
                         count++;
                         break;
                case 3 : int j = scan.nextInt(); 
                         System.out.println(sb.charAt(j-1));
                         break;
                case 4 : count--;
                	sb = new StringBuffer(s[count]);
                         break;
                
            }
            
        }

	}

}

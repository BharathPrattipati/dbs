package com.arrays.practice;

import java.util.Scanner;

public class StringSolution {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		StringBuffer sb = new StringBuffer("");
		while(s.hasNext())
		{
			sb.append(s.next());
		}
		System.out.println(sb.toString());
		

	}

}

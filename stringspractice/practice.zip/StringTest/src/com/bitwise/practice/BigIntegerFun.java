package com.bitwise.practice;

import java.math.BigInteger;

public class BigIntegerFun {

	public static void main(String[] args) {
		BigInteger bg = new BigInteger("90");
		BigInteger bg1 = new BigInteger("12");
		System.out.println(bg);
		System.out.println(bg.bitCount());// No of ones in the binary representation of number
		System.out.println(bg.bitLength());//No of bits used to represent the number
		System.out.println(bg1.getLowestSetBit()); // gets the index of first occurance of 1 from right end
		System.out.println(bg.gcd(bg1)); // give Greatest common divisor of the numbers
		System.out.println(bg.divide(bg1));// quotient will be returned
		System.out.println(bg.divideAndRemainder(bg1));// returns quotient and reminder
		System.out.println(bg.flipBit(1)); // flips the bit at given position
		StringBuffer sb = new StringBuffer("");
	}

}

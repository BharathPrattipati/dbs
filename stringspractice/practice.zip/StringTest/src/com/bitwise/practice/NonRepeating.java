package com.bitwise.practice;

import java.util.Arrays;

public class NonRepeating {

	public static void main(String[] args) {
		int[] in = {10,20,15,22,35};
		/*int res = 0;
		for(int i: in)
		{
			res^=i;
		}
		System.out.println(res);*/
		Arrays.sort(in);
		System.out.println(Arrays.binarySearch(in, 20));
	}

}

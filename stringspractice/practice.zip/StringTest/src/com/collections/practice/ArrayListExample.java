package com.collections.practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListExample {

	private static List<Integer> l1;

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		for(int i=0; i<100; i++)
		{
			list.add(i);
		}
		System.out.println(list);
		l1 = list.subList(10, 20);
		list.removeIf((x)-> x%2!=0); //removing elements from list using specific condition
		System.out.println(list);
		Collections.shuffle(list); // Shuffles the list with some randomness
		System.out.println(list);
		System.out.println(Collections.binarySearch(list, 30)); // with out sorting the list/array binary search will fetch abnormal results
		Collections.sort(list); // Sorts the 
		System.out.println(list);
		System.out.println(Collections.binarySearch(list, 30)); // Sort the list/array before using binary search
		List<Integer> l2 = new ArrayList<Integer>(list);
		Collections.copy(l2, list);
		System.out.println(l2);
		System.out.println(Collections.frequency(list, 10));
		
	}

}

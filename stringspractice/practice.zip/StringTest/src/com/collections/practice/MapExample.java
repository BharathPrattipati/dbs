package com.collections.practice;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;



public class MapExample {

	public static void main(String[] args) {
		Map<Integer,String> map = new HashMap<Integer,String>();
		String s = "aabbbccddaabccdbca";
		map.put(1, "ONE");
		map.put(2, "TWO");
		map.put(3, "THREE");
		map.put(4, "FOUR");
		map.put(5, "FIVE");
		map.put(6, "SIX");
		map.put(7, "SEVEN");
		map.compute(8, (k,v) -> v == null ? map.put(8, "EIGHT") : map.get(8));
		System.out.println(map);
		map.compute(6, (k,v) -> v == null ? map.put(8, "EIGHT") : map.get(8));
		/*for(Map.Entry<Integer, String> entry : map.entrySet())
		{
			entry.
		}*/
		map.forEach((k,v) -> System.out.println("key "+k +" value: "+v));
		HashMap<String, String> hm = new HashMap<String, String>();
        //add key-value pair to hashmap
        hm.put("first", "FIRST INSERTED");
        hm.put("second", "SECOND INSERTED");
        hm.put("third","THIRD INSERTED");
        System.out.println(hm);
        Set<String> keys = hm.keySet();
        /*for(String key: keys){
            System.out.println("Value of "+key+" is: "+hm.get(key));
        }*/
        hm.forEach((k,v) -> System.out.println("Value of "+k+" is: "+v) );
		
	}

}

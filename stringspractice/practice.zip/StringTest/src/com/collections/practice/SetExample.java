package com.collections.practice;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetExample {

	public static void main(String[] args) {
		TreeSet s  = new TreeSet();
		Object[] a = new Object[100];
		for(int i=0;i<100;i++)
			s.add(i);
		System.out.println(s);
		System.out.println(s.headSet(20));
		System.out.println(s.ceiling(20));
		System.out.println(s.first());
		System.out.println(s.floor(30));
		System.out.println(s.higher(40));
		System.out.println(s.last());
		System.out.println(s.headSet(20, true));
		System.out.println(s.tailSet(80));
		System.out.println(s.toArray(a));
		

	}

}

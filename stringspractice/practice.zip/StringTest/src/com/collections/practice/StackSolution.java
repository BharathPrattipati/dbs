package com.collections.practice;

import java.util.Collections;
import java.util.Scanner;
import java.util.Stack;

public class StackSolution {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		int[] input = new int[num];
		Stack s = new Stack();
		int count = 0;
		int max = 0;
		for(int i=0; i<num; i++){
			int option = scan.nextInt();
			if( option == 1 )
			{
				int e = scan.nextInt();
				s.push(e);
			}
			if( option == 2 )
			{
				s.pop();
			}
			if( option == 3 )
			{
				
				System.out.println("Top element is: "+Collections.max(s));
			}
			System.out.println(s);
		}
	}

}

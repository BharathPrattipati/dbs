package com.collections.practice;

import java.util.Scanner;

public class TwoStrings {

	static String twoStrings(String s1, String s2){
        int l1 = s1.length();
        int l2 = s2.length();
        int size = (l1<=l2) ? l1 : l2;
        for(int i=0; i<size; i++)
        {
        	for(int j=i+1;j<=size;j++)
        	{
        		if(s1.substring(i,j).equals(s2.substring(i,j)))
        		{
        			return "YES";
        		}
        	}
        }
		return "NO";
      }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int q = in.nextInt();
        for(int a0 = 0; a0 < q; a0++){
            String s1 = in.next();
            String s2 = in.next();
            String result = twoStrings(s1, s2);
            System.out.println(result);
        }
    }

}

package com.git.arrays;

public class AndOrXor {

	public static void main(String[] args) {
		int a = 9;
		int b = 6;
		int xor = a^b;
		int and = a&b;
		int or = a|b;
		System.out.println(xor);
		System.out.println(and);
		System.out.println(or);
		System.out.println(and^or);
		System.out.println(and^or&xor);

	}

}

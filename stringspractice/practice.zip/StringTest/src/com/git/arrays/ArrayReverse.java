package com.git.arrays;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ArrayReverse {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		List l = new ArrayList();
		for(int i=0;i<n;i++)
		{
			l.add(scan.nextInt());
		}
		Collections.reverse(l);
		l.stream().forEach(e -> System.out.print(e+" "));
		

	}

}

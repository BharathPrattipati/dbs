package com.git.arrays;

import java.util.Scanner;

public class ArrayRotate {
	
	static void leftShiftArray(int[] a,int k)
	{ 
		int temp = 0;
		int n = a.length;
		for(int i=0; i<k; i++)
		{
			temp = a[i];
			a[i] = a[n-i-1];
			a[n-i-1] = temp;
		}
		for(int i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int k = scan.nextInt();
		int[] a = new int[n];
		for(int i=0;i<n;i++)
		{
			a[i] = scan.nextInt();
		}
		leftShiftArray(a,k);

	}

}

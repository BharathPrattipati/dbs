package com.git.arrays;

import java.util.Scanner;

public class ArrayShift {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int d = scan.nextInt();
		int[] ar = new int[n];
		for(int i=n-1;i>=0;i--)
		{
			ar[(i+d)%(n-1)] = scan.nextInt();
		}
		for(int i : ar)
		{
			System.out.print(i+" ");
		}

	}

}

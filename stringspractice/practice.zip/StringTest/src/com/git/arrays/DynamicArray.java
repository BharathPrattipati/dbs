package com.git.arrays;

import java.util.Scanner;

public class DynamicArray {

	public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner scan = new Scanner(System.in);
        int size = scan.nextInt();
        int query = scan.nextInt();
        int[] arq = new int[3];
        int[][] res = new int[size][size];
        int la = 0;
        int cnt = 0;
        for(int i=0;i<query;i++)
        {
            /*for(int j=0;j<=3;j++)
            {
            	System.out.println("i value:" +j);
            	
                arq[j] = scan.nextInt();
                System.out.println(arq[j]);
            }*/
            if(scan.nextInt() == 1)
            {
                int x = (scan.nextInt()^la)%size;
                int l = res[x].length;
                cnt = l;
                System.out.println(cnt);
                res[x][cnt-1] = scan.nextInt();
                cnt++;
                
            }
            else{
                int x = (scan.nextInt()^la)%size;
                int l = res[x].length;
                la =    scan.nextInt()%l;
                System.out.println(la);
            }
                
            
            
        }
    }

}

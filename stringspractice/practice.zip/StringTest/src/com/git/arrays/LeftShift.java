package com.git.arrays;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.stream.Stream;

public class LeftShift {

	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int[] a = new int[n];
		int k = scan.nextInt();
		ArrayList l = new ArrayList();
		for(int i=0; i<n; i++)
		{
			l.add(scan.nextInt());
		}
		Collections.rotate(l,k);
		System.out.println(l);
	}

}

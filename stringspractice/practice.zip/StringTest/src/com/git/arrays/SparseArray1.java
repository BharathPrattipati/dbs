package com.git.arrays;

import java.util.Scanner;

public class SparseArray1 {

	public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        String[] col = new String[n];
        
        for(int i=0; i<n;i++)
        {
            col[i] = scan.next();
        }
        int q = scan.nextInt();
        String[] que = new String[q];
        for(int i=0; i<q;i++)
        {
            que[i] = scan.next();
        }
        for(String s: que)
        {
            int count = 0;
            for(String s1:col)
            {
                if(s.equalsIgnoreCase(s1))
                {
                    count++;
                }
            }
            System.out.println(count);
        }
    }

}

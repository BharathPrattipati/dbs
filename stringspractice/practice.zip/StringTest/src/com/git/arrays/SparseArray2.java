package com.git.arrays;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.IntStream;

public class SparseArray2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        List<String> l1 = new ArrayList<>();
        while(n-->0)
        {
        	l1.add(scan.next());
        }
        int q = scan.nextInt();
        List<String> l2 = new ArrayList<>();
        while(q-->0)
        {
        	l2.add(scan.next());
        }
        for(String s : l2)
        {
        	System.out.println(Collections.frequency(l1, s));
        }
        
        /*String[] col = new String[n];
        
        for(int i=0; i<n;i++)
        {
            col[i] = scan.next();
        }
        int q = scan.nextInt();
        String[] que = new String[q];
        for(int i=0; i<q;i++)
        {
            que[i] = scan.next();
        }
        for(String s: que)
        {
            int count = 0;
            for(String s1:col)
            {
                if(s.equalsIgnoreCase(s1))
                {
                    count++;
                }
            }
            System.out.println(count);
        }*/

	}

}

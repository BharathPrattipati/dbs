package com.git.practice;

import java.util.Arrays;
import java.util.Scanner;

public class MaximumSubarraySum {

	static long maximumSum(long[] a, long m) {
		long sum = 0;
		long max = 0;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<=a.length;j++)
			{
				sum = (Arrays.stream(a, i, j).sum())%m;
				//Arrays.stream(a, i, j).forEach(System.out::print);
				if(max<sum)
				{
					max = sum;
				}
			}
			
        
		}
		
		return max;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int q = in.nextInt();
        for(int a0 = 0; a0 < q; a0++){
            int n = in.nextInt();
            long m = in.nextLong();
            long[] a = new long[n];
            for(int a_i = 0; a_i < n; a_i++){
                a[a_i] = in.nextLong();
            }
            long result = maximumSum(a, m);
            System.out.println(result);
        }
        in.close();
    }

}

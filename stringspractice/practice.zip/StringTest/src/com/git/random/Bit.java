package com.git.random;

import java.math.BigInteger;
import java.util.Scanner;

public class Bit {

	public static void main(String[] args) {
		 Scanner scan = new Scanner(System.in);
	        int t = scan.nextInt();
	        long sum = 0;
	        for(int i=0;i<t;i++)
	        {
	            int a = scan.nextInt();
	            int b = scan.nextInt();
	            for(int j=a;j<=b;j++)
	            {
	            	
	                BigInteger bg = BigInteger.valueOf(j);
	                
	                sum = (bg.bitCount() == 0)? sum = j==-1?sum+32:sum : bg.bitCount()<32 ? sum+(32-bg.bitCount()) : sum+bg.bitCount(); 
	            }
	            System.out.println(sum);
	        }

	}

}

package com.git.random;

import java.util.Scanner;

public class BonApetit {

	public static void main(String args[] ) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int k = scan.nextInt();
        int[] c = new int[n];
        int sum = 0;
        
        for(int i=0;i<n;i++)
        {
            //c[i] = scan.nextInt();
        	int j = scan.nextInt();
        	if(k != i)
        		sum = sum+ j;//c[i];
        }
        System.out.println(sum);
        int bill = scan.nextInt();
        //int res = sum - c[k];
        int diff = bill-sum/2;
        if(diff > 0)
        {
            System.out.println(diff);
        }
        else
        {
            System.out.println("Bon Appetit");
        }
        
    }

}

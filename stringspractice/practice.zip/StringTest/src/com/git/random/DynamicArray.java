package com.git.random;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class DynamicArray {

	public static void main(String[] args) {
		 Scanner scan = new Scanner(System.in);
	        int n = scan.nextInt();
	        int s = scan.nextInt();
	        int la = 0;
	        int[][] qu = new int[n][n];
	      //  List<int[]> qu = new ArrayList<int[]>();
	        for(int i=0; i<s;i++)
	        {
	        	
	        	int j = scan.nextInt();
	            int x = scan.nextInt();
	            int y = scan.nextInt();
	            int k = (x^la)%n;
	            if(j == 1)
	            {
	                int cnt = 0;
	                qu[k][cnt] = y;
	                System.out.println("y "+y+" k "+k+" cnt "+cnt+"element: "+qu[k][cnt]);
	                cnt++;
	            }
	            if(j == 2)
	            {
	                System.out.println("K: "+k+"sub sq len: "+qu[k].length);
	            	int l = y%(qu[k].length);
	                System.out.println("K: "+k+"length : "+l+qu[k][l]);
	                
	                la = qu[k][l];
	                System.out.println(la);
	            }
	        }

	}

}

package com.git.random;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class TwoCharacters {

static int twoCharaters(String s) {
	
	
        return 0;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int l = in.nextInt();
        String s = in.next();
        int result = twoCharaters(s);
        System.out.println(result);
        in.close();
    }

}

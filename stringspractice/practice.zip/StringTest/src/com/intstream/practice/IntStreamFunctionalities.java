package com.intstream.practice;

import java.util.Arrays;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;

public class IntStreamFunctionalities {

	public static void main(String[] args) {
		int[] in = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
		int sum = IntStream.of(in).sum();
		System.out.println(sum);
		double average = IntStream.of(in).average().getAsDouble();
		System.out.println(average);
		long length = IntStream.of(in).count();
		System.out.println(length);
		System.out.println(IntStream.of(in).filter((x) -> x<10).sum());
		System.out.println(IntStream.of(in).reduce(10, (x,y)->x+y));
		String[] myArray = { "this ", "is ", "a ", "sentence" };
		String result = Arrays.stream(myArray)
		                .reduce("", (a,b) -> a + b);
		System.out.println(result);
		
	}

}

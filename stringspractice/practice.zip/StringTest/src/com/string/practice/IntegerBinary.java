package com.string.practice;

public class IntegerBinary {

	public static void main(String[] args) {
		int i = 10;
		System.out.println(Integer.toBinaryString(i));

	}

}

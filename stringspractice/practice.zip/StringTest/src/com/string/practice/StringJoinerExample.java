package com.string.practice;

import java.util.StringJoiner;

public class StringJoinerExample {

	public static void main(String[] args) {
		StringJoiner sj = new StringJoiner("-", "pre", "suf");
		sj.add("abc");
		sj.add("cde");
		sj.add("efg");
		sj.add("ghi");
		System.out.println(sj.toString());

	}

}

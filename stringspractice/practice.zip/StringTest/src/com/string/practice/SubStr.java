package com.string.practice;

public class SubStr {

	public static void main(String[] args) {
		String s = "Letsseehowitgoes";
		System.out.println(s.substring(0,3));

	}

}
